<? include("header.php"); ?>
    
    <div class="inner-hero">
    	
    	<div class="wrapper">
			<img src="img/job-seekers-hero.jpg" style="left:20px; top: 31px;" />
			
			<div class="heading-wrapper" style="left:350px; top: 50px;" >
				<h1>For Job Seekers</h1>
				<h2>Find the right job for you</h2>
			</div>
    	</div>
    </div>
   
   	<div id="main" class="inner">
   	
   		<div class="left">
   			<span class="title">For Job Seekers</span>
			<p class="results-found">Found 15 results for your search. Please use the form on the right to update your results.</p>
			<select id="sort"><option>Sort by date</option><option>Sort by Salary</option><option>Sort by career level</option><option>Sort by career level</option></select>
			<div class="search-results">
			
				<a class="box" href="job-detail.php">
		   			<h2>Assistant Merchandiser</h2>
		   			<h3>Foot locker sourcing</h3>
		   			<p>Hong Kong, 8-10 years: Our client is the market leader in office supplies. They are looking for a Marketing Manager to participate in planning company's direction, implementing marketing strategies and enhancing the quality process. </p>
					<span>
			   			<div class="first-row">Date posted</div>
			   			<div class="last-row">30 May 2012</div>
					</span>
		   			<span>
			   			<div class="first-row">Location</div>
			   			<div class="last-row">Hong Kong</div>
		   			</span>
					<span>
			   			<div class="first-row">Career level</div>
			   			<div class="last-row">Middle</div>
					</span>
					<span>
			   			<div class="first-row">Salary</div>
			   			<div class="last-row">9k-12k</div>
					</span>
					<span>
			   			<div class="first-row">Employment type</div>
			   			<div class="last-row">Full time</div>
					</span>
					<span>
			   			<div class="first-row">Industry</div>
			   			<div class="last-row">Sales</div>
					</span>
		
		  	 		<div class="expand"></div>
		   		</a>

				<a class="box" href="job-detail.php">
		   			<h2>Assistant Merchandiser</h2>
		   			<h3>Foot locker sourcing</h3>
		   			<p>Hong Kong, 8-10 years: Our client is the market leader in office supplies. They are looking for a Marketing Manager to participate in planning company's direction, implementing marketing strategies and enhancing the quality process. </p>
					<span>
			   			<div class="first-row">Date posted</div>
			   			<div class="last-row">30 May 2012</div>
					</span>
		   			<span>
			   			<div class="first-row">Location</div>
			   			<div class="last-row">Hong Kong</div>
		   			</span>
					<span>
			   			<div class="first-row">Career level</div>
			   			<div class="last-row">Middle</div>
					</span>
					<span>
			   			<div class="first-row">Salary</div>
			   			<div class="last-row">9k-12k</div>
					</span>
					<span>
			   			<div class="first-row">Employment type</div>
			   			<div class="last-row">Full time</div>
					</span>
					<span>
			   			<div class="first-row">Industry</div>
			   			<div class="last-row">Sales</div>
					</span>
		
		  	 		<div class="expand"></div>
		   		</a>

				<a class="box" href="job-detail.php">
		   			<h2>Assistant Merchandiser</h2>
		   			<h3>Foot locker sourcing</h3>
		   			<p>Hong Kong, 8-10 years: Our client is the market leader in office supplies. They are looking for a Marketing Manager to participate in planning company's direction, implementing marketing strategies and enhancing the quality process. </p>
					<span>
			   			<div class="first-row">Date posted</div>
			   			<div class="last-row">30 May 2012</div>
					</span>
		   			<span>
			   			<div class="first-row">Location</div>
			   			<div class="last-row">Hong Kong</div>
		   			</span>
					<span>
			   			<div class="first-row">Career level</div>
			   			<div class="last-row">Middle</div>
					</span>
					<span>
			   			<div class="first-row">Salary</div>
			   			<div class="last-row">9k-12k</div>
					</span>
					<span>
			   			<div class="first-row">Employment type</div>
			   			<div class="last-row">Full time</div>
					</span>
					<span>
			   			<div class="first-row">Industry</div>
			   			<div class="last-row">Sales</div>
					</span>
		
		  	 		<div class="expand"></div>
		   		</a>

				<a class="box" href="job-detail.php">
		   			<h2>Assistant Merchandiser</h2>
		   			<h3>Foot locker sourcing</h3>
		   			<p>Hong Kong, 8-10 years: Our client is the market leader in office supplies. They are looking for a Marketing Manager to participate in planning company's direction, implementing marketing strategies and enhancing the quality process. </p>
					<span>
			   			<div class="first-row">Date posted</div>
			   			<div class="last-row">30 May 2012</div>
					</span>
		   			<span>
			   			<div class="first-row">Location</div>
			   			<div class="last-row">Hong Kong</div>
		   			</span>
					<span>
			   			<div class="first-row">Career level</div>
			   			<div class="last-row">Middle</div>
					</span>
					<span>
			   			<div class="first-row">Salary</div>
			   			<div class="last-row">9k-12k</div>
					</span>
					<span>
			   			<div class="first-row">Employment type</div>
			   			<div class="last-row">Full time</div>
					</span>
					<span>
			   			<div class="first-row">Industry</div>
			   			<div class="last-row">Sales</div>
					</span>
		
		  	 		<div class="expand"></div>
		   		</a>

				<a class="box" href="job-detail.php">
		   			<h2>Assistant Merchandiser</h2>
		   			<h3>Foot locker sourcing</h3>
		   			<p>Hong Kong, 8-10 years: Our client is the market leader in office supplies. They are looking for a Marketing Manager to participate in planning company's direction, implementing marketing strategies and enhancing the quality process. </p>
					<span>
			   			<div class="first-row">Date posted</div>
			   			<div class="last-row">30 May 2012</div>
					</span>
		   			<span>
			   			<div class="first-row">Location</div>
			   			<div class="last-row">Hong Kong</div>
		   			</span>
					<span>
			   			<div class="first-row">Career level</div>
			   			<div class="last-row">Middle</div>
					</span>
					<span>
			   			<div class="first-row">Salary</div>
			   			<div class="last-row">9k-12k</div>
					</span>
					<span>
			   			<div class="first-row">Employment type</div>
			   			<div class="last-row">Full time</div>
					</span>
					<span>
			   			<div class="first-row">Industry</div>
			   			<div class="last-row">Sales</div>
					</span>
		
		  	 		<div class="expand"></div>
		   		</a>

			
			
			</div>

   		</div> <!-- end of left -->
   		
   		
   		<div class="right">
	   		<div class="job-search-box">
	   			<h2>Update results</h2>
	   			<form method="" action="job-results.php">
	   				<input type="text" id="role" name="role" value="Assistant Merchandiser" />
	   				<select name="industry" id="industry">
	   					<option value="0">Finance</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   				</select>
	   				<select name="location" id="location">
	   					<option value="0">Hong Kong</option>
	   					<option>Hong Kong</option>
	   					<option>Hong Kong</option>
	   					<option>Hong Kong</option>
	   				</select>
	   				<select name="salary" id="salary">
	   					<option value="0">25k ></option>
	   					<option></option>
	   					<option></option>
	   					<option></option>
	   				</select>
	   				<select name="contract_type" id="contract_type">
	   					<option value="0">Full time</option>
	   					<option>Part time</option>
	   				</select>
	   				
	   				<input type="submit" value="update results" class="btn blue" />
					<a class="btn grey">Quick submit CV</a>
	   				
	   			
	   			</form>
	   		</div>
	   		
	   		<div class="box image">
	   			<img src="img/salary-guides.jpg" alt="salary-guides" width="285" height="148" />
	   			<div class="expand"></div>
	   		</div>
	   	</div><!-- end of right -->
	   	
	   	<div class="clearfix"></div>
	   	
   </div><!-- end of main -->
   
   

   
<? include("footer.php"); ?>