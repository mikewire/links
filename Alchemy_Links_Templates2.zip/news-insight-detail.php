<? include("header.php"); ?>
    
    <div class="inner-hero">
    	
    	<div class="wrapper">
			<img src="img/news-insight-hero.jpg" style="left:100px; top: 30px;" />
			
			<div class="heading-wrapper" style="left:450px; top: 50px;" >
				<h1>News & Insight</h1>
				<h2>Latest industry trends from our specialists</h2>
			</div>
    	</div>
    </div>
   
   	<div id="main" class="inner">
   	
   		<div class="left">
   			<span class="title">News & Insight</span>
   			<a class="back btn grey" href="news-insight.php">Back</a>
	 	   	<div class="article-detail">
	   			<span class="date">28 May 2012</span>
	   			<h3>Our take on the salary trends of 2012</h3>
	   			<span class="two-lines"></span>
				<img src="img/news-detail-sample1.jpg" alt="news-detail-sample1" width="861" height="320" />
	   			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate </p>
	   			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate </p>
	   			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate </p>
	   			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate </p>

	   			<span class="two-lines"></span>
		   		<div class="author-area">
		   		
		   			<span class="heading">Author</span>
		   			<img src="img/author.jpg" alt="author" width="81" height="82" />
		   			<span class="bio">
		   				<h4>Helen Hanson</h4>
		   				<p>HR Services Consultant/Career Transition Services Manager<br />
at (852) 2116-1020<br />
<a href="hrservices@linksrecruitment.com">hrservices@linksrecruitment.com</a> </p>
		   			</span>
		   			<div class="share"><!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style ">
<a class="addthis_button_preferred_1"></a>
<a class="addthis_button_preferred_2"></a>
<a class="addthis_button_preferred_3"></a>
<a class="addthis_button_preferred_4"></a>
<a class="addthis_button_compact"></a>
<a class="addthis_counter addthis_bubble_style"></a>
</div>
<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=xa-501207c80066b03b"></script>
<!-- AddThis Button END --></div>
		   			<div class="clearfix"></div>
		   		</div>
		   		
		   	</div>
  		

   		</div> <!-- end of left -->
   		
   		
   		<div class="right">
	   		<div class="job-search-box">
	   			<h2>Looking for a job?</h2>
	   			<form method="" action="job-results.php">
	   				<input type="text" id="role" name="role" placeholder="Type in your role, e.g. sales" />
	   				<select name="industry" id="industry">
	   					<option value="0">In any industry</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   				</select>
	   				<select name="location" id="location">
	   					<option value="0">In any location</option>
	   					<option>Hong Kong</option>
	   					<option>Hong Kong</option>
	   					<option>Hong Kong</option>
	   				</select>
	   				<select name="salary" id="salary">
	   					<option value="0">For any salary</option>
	   					<option></option>
	   					<option></option>
	   					<option></option>
	   				</select>
	   				<select name="contract_type" id="contract_type">
	   					<option value="0">Full time</option>
	   					<option>Part time</option>
	   				</select>
	   				
	   				<input type="submit" value="Find job" class="btn blue" />
					<a class="btn grey">Quick submit CV</a>
	   				
	   			
	   			</form>
	   		</div>
	   		
	   		<div class="box image">
	   			<img src="img/salary-guides.jpg" alt="salary-guides" width="285" height="148" />
	   			<div class="expand"></div>
	   		</div>
	   	</div><!-- end of right -->
	   	
	   	<div class="clearfix"></div>
	   	
   </div><!-- end of main -->
   
   

   
<? include("footer.php"); ?>