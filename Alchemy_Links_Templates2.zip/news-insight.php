<? include("header.php"); ?>
    
    <div class="inner-hero">
    	
    	<div class="wrapper">
			<img src="img/news-insight-hero.jpg" style="left:100px; top: 30px;" />
			
			<div class="heading-wrapper" style="left:450px; top: 50px;" >
				<h1>News & Insight</h1>
				<h2>Latest industry trends from our specialists</h2>
			</div>
    	</div>
    </div>
   
   	<div id="main" class="inner">
   	
   		<div class="left">
   			<span class="title">News & Insight</span>
	 	   	<div class="articles">
		   		
		   		<a class="box" href="news-insight-detail.php">
		   			<span class="date">28 May 2012</span>
		   			<h2>Our take on the salary trends of 2012</h2>
		   			<span class="two-lines"></span>
		   			<img src="img/news-insight-sample-2.png" alt="news-insight-sample-2" width="251" height="141" />
		   			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate </p>
		   			<div class="expand"></div>
		   		</a>

		   		<a class="box" href="news-insight-detail.php">
		   			<span class="date">28 May 2012</span>
		   			<h2>Our take on the salary trends of 2012</h2>
		   			<span class="two-lines"></span>
		   			<img src="img/news-insight-sample-1.png" alt="news-insight-sample-1" width="251" height="141" />
		   			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
		   			<div class="expand"></div>
		   		</a>

		   		<a class="box" href="news-insight-detail.php">
		   			<span class="date">28 May 2012</span>
		   			<h2>Our take on the salary trends of 2012</h2>
		   			<span class="two-lines"></span>
		   			<img src="img/news-insight-sample-1.png" alt="news-insight-sample-1" width="251" height="141" />
		   			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
		   			<div class="expand"></div>
		   		</a>

		   		<a class="box" href="news-insight-detail.php">
		   			<span class="date">28 May 2012</span>
		   			<h2>Our take on the salary trends of 2012</h2>
		   			<span class="two-lines"></span>
		   			<img src="img/news-insight-sample-1.png" alt="news-insight-sample-1" width="251" height="141" />
		   			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
		   			<div class="expand"></div>
		   		</a>

		   		<a class="box" href="news-insight-detail.php">
		   			<span class="date">28 May 2012</span>
		   			<h2>Our take on the salary trends of 2012</h2>
		   			<span class="two-lines"></span>
		   			<img src="img/news-insight-sample-1.png" alt="news-insight-sample-1" width="251" height="141" />
		   			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		   			<div class="expand"></div>
		   		</a>

		   		<a class="box" href="news-insight-detail.php">
		   			<span class="date">28 May 2012</span>
		   			<h2>Our take on the salary trends of 2012</h2>
		   			<span class="two-lines"></span>
		   			<img src="img/news-insight-sample-1.png" alt="news-insight-sample-1" width="251" height="141" />
		   			<p>Lorem ipsum dolor sit amet, </p>
		   			<div class="expand"></div>
		   		</a>

		   		<a class="box" href="news-insight-detail.php">
		   			<span class="date">28 May 2012</span>
		   			<h2>Our take on the salary trends of 2012</h2>
		   			<span class="two-lines"></span>
		   			<img src="img/news-insight-sample-1.png" alt="news-insight-sample-1" width="251" height="141" />
		   			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
		   			<div class="expand"></div>
		   		</a>
		   	
		   	</div>
  		

   		</div> <!-- end of left -->
   		
   		
   		<div class="right">
	   		<div class="job-search-box">
	   			<h2>Looking for a job?</h2>
	   			<form method="" action="job-results.php">
	   				<input type="text" id="role" name="role" placeholder="Type in your role, e.g. sales" />
	   				<select name="industry" id="industry">
	   					<option value="0">In any industry</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   					<option>Finance</option>
	   				</select>
	   				<select name="location" id="location">
	   					<option value="0">In any location</option>
	   					<option>Hong Kong</option>
	   					<option>Hong Kong</option>
	   					<option>Hong Kong</option>
	   				</select>
	   				<select name="salary" id="salary">
	   					<option value="0">For any salary</option>
	   					<option></option>
	   					<option></option>
	   					<option></option>
	   				</select>
	   				<select name="contract_type" id="contract_type">
	   					<option value="0">Full time</option>
	   					<option>Part time</option>
	   				</select>
	   				
	   				<input type="submit" value="Find job" class="btn blue" />
					<a class="btn grey">Quick submit CV</a>
	   				
	   			
	   			</form>
	   		</div>
	   		
	   		<div class="box image">
	   			<img src="img/salary-guides.jpg" alt="salary-guides" width="285" height="148" />
	   			<div class="expand"></div>
	   		</div>
	   		<div class="box grey-gradient">
	   			<h2>MPF in the community</h2>
	   			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut.</p>
	   			<div class="expand"></div>
	   		</div>
	   	</div><!-- end of right -->
	   	
	   	<div class="clearfix"></div>
	   	
   </div><!-- end of main -->
   
   

   
<? include("footer.php"); ?>